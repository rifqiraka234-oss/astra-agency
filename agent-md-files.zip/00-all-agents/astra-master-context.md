# ASTRA Agency — Master AI Context

> **Zero mistake policy. Read `CLAUDE.md` "TRIPLE CHECK EVERYTHING" before acting on
> this file (Raka, 2026-09-21).** Every claim gets three different checks, not three
> readings. Reopen the source, actively try to prove the claim false, then confirm it a
> second way that does not share a failure mode with the first. Every absence claim ships
> with a positive control showing the method finds the thing when it is there. My own
> notes, state files and memory are a candidate list, never proof.
>
> **Being lazy is prohibited.** If a tool, an API call or a fetch can settle a question,
> it settles it. Never reason from a timestamp, a preview, a filename, a pattern or a
> plausible guess to save a call. An inference that turns out right is still a process
> failure. For this file that means every commercial term, price and prospect fact here is date
> sensitive and gets confirmed live before it is quoted to anyone outside.

> Source: `ASTRA_Agency_Master_AI_Context_1.docx`, version date 6 August 2026.
> Condensed for repo use; nothing here should be treated as more current than
> a live correction from Raka in an actual conversation. This is the business
> and voice context behind every message the enrichment pipeline and inbox
> triage routines draft. Commercial terms and prospect facts are
> date-sensitive, confirm before quoting externally.

## Truth hierarchy (read before trusting anything below)

1. A direct instruction or correction from Raka in the current conversation.
2. A confirmed current ASTRA rule or the most recent operating framework.
3. A dated ASTRA deck or commercial working version (this document).
4. Verified public facts about a prospect or client.
5. Company-reported claims, which must remain labelled as such.
6. Reasonable hypotheses, which can guide discovery but must not be written as facts.
7. Old drafts, experiments and lead-specific ideas, which are not universal policy.

Never silently merge contradictions. Preserve dates and versions, and ask
before quoting an uncertain commercial term externally.

## 1. Agency identity

ASTRA Agency is a Netherlands-based boutique digital and innovation agency.
Positioning: *"Boutique digital & innovation partner for Dutch businesses.
Grow. Optimise. Innovate."*

Value proposition combines: Dutch-facing strategy/scoping/PM/communication;
branding, UX, website, product and service thinking; experienced design and
development capacity through an Indonesian delivery partner (Amwisesa, under
the JMVentures x Amwisesa structure); fixed scopes and transparent ranges
instead of open-ended billing; Dutch boutique control at Indonesian-house
cost base.

Mission: helping businesses thrive through tailored and affordable digital
and innovation solutions. Vision: becoming the go-to digital and innovation
agency for Dutch businesses not usually covered by the mainstream market.
Values: trustworthiness, craftsmanship, partnership, transformation, premium.
"Affordable" does not mean cheap or template-based.

**Why ASTRA exists** — recurring problems it solves: an outdated/unclear
website despite a working offer; manual work still on spreadsheets/paper/
email/WhatsApp; revenue that can't scale without proportional manual effort;
systems that don't talk to each other; innovation ideas stuck in Miro/Notion/
people's heads; no internal capacity to scope/prototype/build; Dutch agency
rates around €100-150/hour being out of reach; too small for a major
consultancy or internal innovation department.

The promise is not "a prettier website" — it's clearer customer-facing
growth, lower operational friction, or a better path from idea to validated
product.

## 2. Team

- **Rifqi Rakamulya / Raka** — ASTRA lead, primary commercial/strategy
  voice. Netherlands-based. Leads prospecting, research, qualification,
  outreach, client conversations, pricing, project framing, workshops.
  Prior low-code/software sales background (Betty Blocks). **Outreach must
  sound like Raka wrote it, not like an automated audit.**
- **Joshua / Josh van Zeelt** — website/app implementation, prototypes,
  portals, technical delivery. Associated with JMVentures in the deck.
- **Luna** — branding, visual identity, brand personality, psychologically
  informed positioning.
- **Amwisesa (Indonesia)** — senior design/development capacity, 10+ years,
  directed under clear Netherlands direction. ASTRA owns project clarity,
  communication, quality control and the commercial relationship.

## 2A. Raka's own profile (the credibility we can actually spend)

Source: Raka's LinkedIn, pasted by him 2026-09-13. This is the factual record
behind every "I have done this myself" line in outreach. Use it to earn the
right to an opinion. Never stretch it, and never claim Astra did something
that Raka did somewhere else.

**Identity.** Raka Mulya, full name Rifqi Rakamulya. He/Him. Based in the
Randstad, Netherlands. `linkedin.com/in/raka-mulya-b92885196`. 500+
connections, around 1,550 followers. Indonesian, moved to the Netherlands in
2018. English native or bilingual, Dutch limited working, plus Indonesian.

**Current headline.** "Just a curious guy with many skills | Manager Sales &
Revenue Operations | Ex HEINEKEN Global | Founder of a Stroopwafel business |
2017 Asian Karting Champion"

**Roles, most recent first.**

- **Sales & Channel Operations Manager, efficy** (2026 to present). CRM
  vendor.
- **Advisor, Astra Agency** (Jan 2026 to present, Amsterdam Area). His own
  framing on LinkedIn is modest, "helping my sister and my friend with
  starting their digital agency."
- **Global GTM & Campaign Manager, Betty Blocks** (Aug 2024 to Feb 2026).
  ICP segmentation, account selection, messaging and multi-channel outreach;
  automation-driven revenue workflows covering enrichment, scoring, routing
  and follow-up loops; playbooks and cadences across SDR, AE, Marketing and
  RevOps; pipeline generation through structured experimentation.
- **CEO and CMO, Eten Maar** (Aug 2020 to Dec 2024, South Jakarta). Founded
  and scaled a stroopwafel brand from zero with five relatives. Owned
  acquisition, partnerships, content, conversion, pricing, inventory and unit
  economics. Expanded to Bali, where he lived for seven months.
- **Global E-Business Data & Insights Lead, The HEINEKEN Company** (Feb 2023
  to Feb 2024, Amsterdam). Standardised KPIs, dashboards and decision
  cadences; enabled **23 markets** with self-serve insights; data governance
  across regions.
- **Freelance social media and branding consultant** (Dec 2020 to Feb 2023,
  Bali). Notable clients Gudang Garam Tbk (Indonesian tobacco) and Maxime
  Indonesia (appliances).
- **Project Manager, Pandan Social** (Mar to Nov 2022, Kuala Lumpur).
  Influencer campaigns end to end.
- **Race kart driver, Stratos Motorsports** (2015 to 2022). **2017 Asian
  Karting Champion, Senior category.** Racing is what opened the door to
  studying in Europe; the career stalled on funding during COVID.
- Junior consumer analyst and market researcher roles in Jakarta, 2020 to 2021.

**Education.** MSc Digital Business & Innovation, Vrije Universiteit
Amsterdam (2022 to 2023). BSc International Business Administration,
E-Marketing, Rotterdam School of Management, Erasmus (2018 to 2021).

**Top skills as listed.** B2B, Digital Strategy, Digital Transformation, IT
Transformation. Tools on the profile: HubSpot, Replit, Gamma, IntelliJ.

**Outside work, and it is genuinely useful material.** Hard techno DJing
(999999999, I Hate Models, SNTS). Marathon running, Leiden and Amsterdam.
Yoga and meditation. The racing discipline shows up in how he talks about
preparation and repetition.

### How to use this in outreach

Match the credential to the lead, and use one, not a list.

- **Owner-operator or founder lead** (most of the ICP). Eten Maar. He built a
  food brand from zero with family, ran the P&L, did the pricing and the
  inventory. He is not an agency guy talking at a founder, he has had the
  same week they are having.
- **Corporate, enterprise or anyone who cares about scale.** Heineken, 23
  markets, global e-business analytics. This buys credibility fast with
  operations and data people.
- **RevOps, GTM, sales leadership, SaaS.** Betty Blocks and efficy. Pipeline
  systems, enrichment, scoring, routing, playbooks. This is the closest match
  to what Astra actually sells under Grow and Optimise.
- **Energy, industrial, engineering, German-speaking and other operations-led
  businesses.** Lead with Heineken and the process and data work, not the
  agency. These buyers respect an operator far more than a creative.
  Relevant to **Niklas / Nikolas Wagner at Wagner Energy Solutions**, where
  the standing draft should carry the operations credential rather than a
  design pitch.
- **When rapport genuinely helps and only then.** Karting champion, techno,
  marathons. Never as an opener, and never as a substitute for a specific
  observation about their business.

### His own writing voice, observed from his posts

Useful because outreach has to sound like him. His posts run personal anecdote
into a business lesson, first person throughout, warm and self-deprecating,
plain words, short paragraphs, often a question at the end. Recurring themes:
the habit of winning over wanting to win, showing up at one percent a day
rather than waiting to feel ready, revenue teams should be like pasta
(reliable, simple, makes you feel good), AI agents doing real work while he is
at the gym, respect for ordinary founders just trying to make a living,
documenting processes to kill tribal knowledge, and a health-makes-money
argument. His single best performing post by a wide margin was an observation
about Albert Heijn's floor-cleaning robots and labour shortage, at 74,611
impressions, which is worth remembering: a specific, real observation about
somebody else's business massively outperformed his motivational posts.

Two differences between his personal posting and our outreach. He uses emoji
freely in his own posts; outreach does not. He uses colons in posts; outreach
never does, per his own total ban.

## 3. Market position and ideal clients

**Primary target types:** founder-led SMEs; small/mid-market orgs with real
customers; self-employed professionals, coaches, consultants; clinics,
healthcare, fitness, hospitality, service businesses; ecommerce/consumer
brands; operational companies still running on email/Excel/paper/WhatsApp;
growing startups with unclear or multi-audience websites; orgs with complex
customer/partner/investor/booking journeys; agencies/product studios/solo
devs needing extra backend or full-stack capacity; businesses with ideas but
no internal capacity to scope and build them.

**Indicative investment fit:** roughly €5,000-€50,000 one-off or a matching
monthly budget. Larger integrated platforms can exceed this.

**Disqualifiers / caution flags** — probably not a fit when: the buyer only
wants a €999 template site; no one internally can own the project; the
client wants everything immediately without engaging with process
decisions; the visible issue is purely aesthetic with no commercial or
operational consequence; the org can't implement the concept or fund a
plausible next step; regulatory/legal/reputational risk makes ASTRA unable
to represent the business responsibly; the lead is only attractive because a
prototype would look interesting; the company is a direct competitor to
ASTRA; the current site is already commercially strong for the company's
stage with no stronger ASTRA angle available.

**Lead-quality factors:** relevance to an ASTRA proposition, commercial
potential, visible urgency, access to a decision-maker, ability/willingness
to invest, prototype leverage, likelihood of implementation, legal/
compliance/reputation safety, whether the opportunity justifies deep
personalisation.

## 4. Service architecture

Four propositions. **Never force every lead into a website redesign** — pick
the one that actually fits.

**Grow Your Business** — customer-facing digital experiences (websites,
landing pages, funnels, booking flows, UX/UI, copy, frontend/backend,
integrations, portals, analytics, security hardening). Realistic outcomes:
faster comprehension, stronger trust, easier discovery, clearer routing,
more relevant enquiries/bookings, better qualification, less abandonment,
fewer avoidable pre-sales questions. Do not claim a redesign creates more
*traffic* unless SEO/campaigns/content/another acquisition mechanism is
actually included.

**Optimise Your Business** — internal tools and workflows that cut manual
effort (internal apps, approval workflows, staff/partner/client portals,
dashboards, inventory/warehouse/order systems, scheduling, document flows,
role-based access, integrations, replacing spreadsheet/email/paper/WhatsApp
processes). Realistic outcomes: fewer manual/duplicated steps, fewer errors
and delays, faster approvals, better visibility, fewer status questions,
less admin/payroll waste, more capacity without adding FTEs.

**Innovate Your Business** — structured path from idea to evidence/decision/
roadmap (discovery, business-model analysis, workshops, service design,
clickable prototypes, feasibility, validation, go/no-go, roadmaps, MVP
planning). Not day-to-day optimisation, not automatically a full build.

**Build Squad / Agency Partnership** — white-label or extra dev capacity for
agencies/product businesses with more client work than internal capacity, a
missing backend/full-stack skillset, or a clear backlog needing reliable
execution.

## 5. Commercial framework (indicative, confirm before quoting)

All prices scope-dependent, do not quote externally without confirming the
current version.

| Package | Fit | Price |
|---|---|---|
| Grow A — Launch Essentials | Fast professional presence | €5,500-6,500 one-off |
| Grow B — Growth Ready | Product-market fit, active growth | €8,500-12,500 one-off (+ Basic Care ~€650/mo working variant) |
| Grow C — Scale & Innovate | Long-term digital partner | €17,000-22,000 build + €1,300/mo growth |
| Optimise O1 — Workflow Booster | One low-complexity process win | €5,500-9,500 |
| Optimise O2 — Operations System | One operational domain end-to-end | €17,000-27,000, ~€1,300/mo retainer |
| Optimise O3 — Integrated Platform | Multi-domain custom platform | €35,000-70,000+, €1,750-2,500/mo |
| Innovate I1 — Sprint | Validated concept in 1-2 weeks | ~€7,500 |
| Innovate I2 — Roadmap & Business Case | Portfolio of initiatives, 4-8 weeks | ~€15,000 |
| Innovate I3 — Partner Retainer | Continuous sparring, 6-12mo min | €3,000/mo |
| Build Squad | 1 FTE dev + 0.5 FTE PM pod, 3-6mo min | €10,000/mo |

Ad hoc: dev ~€375/day (€50/hr), PM/UX/strategy ~€550/day (€75/hr).
Basic Care €650/mo, Growth Care €1,300/mo. Pen-test add-on ~€17,500 (deck) to
~€20,000 (market-working note) — versions conflict, do not average, confirm
current supplier scope. Internal margin benchmarks (e.g. ~€120/supplier day)
are never client-facing.

## 6. Delivery model

Free intake call (30-45 min) → match to a starting point (Grow / Optimise /
Innovate / Build Squad) → clear scope, price, timeline → discovery and
prioritisation before build → design the journey/workflow/concept → build
under Dutch direction with regular check-ins → QA → launch with hypercare →
continue via care/growth/innovation retainer.

Principles: fixed scopes over "uurtje-factuurtje"; prioritise for impact;
client must have an internal owner; scope/dependencies/unknowns explicit;
never propose something the prospect can't plausibly implement; keep
customer-facing deliverables separate from strategy commentary.

## 7. Core strategic and analytical method

Required reasoning pattern: **what we noticed → what we would change → what
realistic business result it should support.** For each issue: what's
publicly visible, where it breaks down, which visitor/buyer/partner/internal
user is affected, which decision gets harder, which realistic KPI suffers,
what ASTRA could demonstrate or build. Avoid generic observations like "the
website could be more modern."

**Evidence classification** — every material claim is one of: Verified fact,
Company-reported claim, Reasonable hypothesis, or Unknown. Never invent
internal processes, prices, inventory, conversion rates, revenue splits,
partnerships, policies, dates, statistics, regulatory status or roadmap
items.

**Red-team before finalising:** wrong person/company? Has it pivoted? Is the
issue actually important or just taste? Does another page already resolve
this? Is the site intentionally serving another goal? Is a different ASTRA
proposition stronger? Is the company already too mature for what's proposed?
Can the prospect implement/afford the concept? Would the founder feel
understood or immediately correct us? Is the prototype worth the time?

## 8. Lead qualification and output format

Verdicts: Strong lead / Worth pursuing / Interesting but lower priority /
Different ASTRA angle / Skip. Confidence labels (High/Medium/Low) for
identity, business-understanding, and website-analysis. Scoring dimensions
(0-5): relevance, commercial potential, visible urgency, decision-making
access, prototype-demonstrability, likelihood of implementation, reputation/
compliance safety.

## 9. Outreach voice and writing rules (read before drafting any message)

**Core voice:** natural, concise, calm, direct, intelligent, constructive.
Highly specific without sounding like a forensic report. One business owner
speaking to another. Use **"our agency,"** never wording that makes ASTRA
sound like a solo freelancer. Every word must add value. Show useful
thinking before asking for time. A slightly "roasty" critique is fine when
accurate and empathetic — never insult the founder or the existing site.

**Punctuation guardrails (hard, same weight as the no-dash rule; Raka
2026-08-19):** never use a colon (`:`) anywhere in an outreach message, and
never use hyphens, en dashes, or em dashes. Both read as machine-written.
Rewrite around them: instead of "One thing I noticed: X", write "One thing I
noticed, X" or split into two sentences. A colon inside a URL the message
links to is fine (it is part of the link, not prose); the ban is on colons
in the message text itself.

**Preferred rhythm:** thank them for connecting when appropriate → state
what ASTRA understands about the business → one or two specific observations
→ introduce a concrete ASTRA direction → connect it to a realistic outcome →
low-friction CTA.

### The message template

This is the confirmed structure for the post-acceptance first message,
combining the master context's recurring pattern with Raka's exact working
template (2026-08-12 correction: **65 words max**, tighter than the master
context's general 90-150 word guidance — the tighter cap wins per the truth
hierarchy, Raka's live instruction beats the older deck target):

```
Hey [name], thanks for connecting. I saw [business], and [what the business
does] is [a sharp angle / amazing / novel — whatever is genuinely earned].
However, [specific problem about the website], so [cost of doing nothing,
tied to their actual business goal]. Our agency sketched [what was sketched]
so [how it solves the problem]. Want me to send it over?
```

Do not copy it mechanically — every bracket must be filled with something
specific and verified, never a generic filler. If it doesn't fit in 65
words with every clause earning its place, trim the cost-of-inaction clause
first, the opener and the "sketched" clause carry the most weight.

**Open like a human who actually looked (Raka, 2026-08-19).** The first line
is a real person reacting to their work, not a formal set-up: *"I saw
[company] does [specific real thing], really cool"* / *"that's interesting"*
/ *"nice"* / *"vet werk"*. Lead with the genuine, specific observation and a
plain casual reaction, then the "wat me opviel / one thing I noticed"
problem, then the offer. Read every draft aloud: if a sentence sounds like a
brochure or a chatbot ("verzorgt de vastgoedmedia", "runs programmes at the
intersection of"), rewrite it the way you'd actually message another owner.
Use "we sketched / we put together" (the agency, but human and first-person),
not the stiff "our agency sketched a homepage that opens with…".

**Match the lead's existing language (Raka, 2026-08-19).** Before drafting,
look at what language was actually sent to this specific lead and what
language the thread is in, and stay consistent — do not switch English to
Dutch or back mid-conversation. The connection note in the v0.1 campaign went
out in English to everyone, so a lead whose thread is still English stays
English unless we already switched them to their own language earlier in the
thread. When in doubt, match the language of the most recent real message in
that thread.

**First move is the visual-era roast (Raka, 2026-09-03).** Before any deeper
angle research, open the live site as a screenshot and judge its era. If it
visibly reads like a 2010s / early-template build (dated stock hero, tiny
logo, gradient buttons, Bootstrap-era cards, cramped mobile, clip-art icons),
that is a for-sure website / Grow angle on its own, go straight to the
prototype offer and do not hunt for a cleverer angle. Frame the cost (trust
and conversion lost the moment a buyer lands), never the taste, and still
confirm it is their live main domain and not a deliberate choice (Learning
ledger #11). Only when the site already looks current and well built do you
research further for the real bottleneck per
`docs/astra-commercial-angle-master.md`, or return `NO_STRONG_ANGLE`.

**The opener always names a website problem and offers a prototype
(Raka, 2026-08-19, live instruction, outranks older nuance).** Every
post-acceptance first message follows the template above: name a specific,
real problem with *their website* and offer to send a prototype/mock
homepage. Do not soften a warm lead into a no-pitch relationship opener,
and do not decide a site is "too strong to critique" and skip the offer —
every site has a real, specific weak point, so find the honest one and lead
with it. The one hard limit is the no-fabrication rule: the problem must be
something actually verified on their live site (fetch it and confirm before
sending), never invented to fit the template. "Strong site" means look
harder for the real gap (missing proof, service-menu instead of outcome,
mission-first with no concrete offer, no pricing, buried credibility), not
send a weaker message.

**Preferred wording:** "I had a look at…", "from what I understand…",
"however…", "this may make it harder for…", "a clearer homepage direction",
"a concept showing what we mean", "our agency sketched…", "Want me to send
it?", "Shall I send the sketch?", "Want the one-pager?", "send a mock
homepage" (when that's the actual artifact).

### Follow-up psychology, honest FOMO and loss aversion (Raka, 2026-08-19)

Nudges convert better when they use real persuasion pressure, not fake
urgency. Kahneman and Tversky showed a loss is felt about twice as hard as
the equivalent gain, and Cialdini's scarcity principle raises perceived
value only when the scarcity is believable. Use these three honest levers,
and only these:

- **Loss aversion / cost of inaction, in the present tense.** Frame what
  they are losing *right now* by leaving it, not what they might gain.
  "Every week it stays like this, the funders who would have got it are
  piecing the model together themselves" beats "this would help funders."
  Make the loss concrete and ongoing (visitors bouncing, enquiries walking
  out, months of funding slipping), and true to what was actually verified.
- **The endowment effect.** The prototype already exists and was built for
  them. Say so, plainly, "it is already built and sitting there", "it is
  yours to keep either way". People weigh losing something that is already
  theirs more heavily than acquiring something new, so a decline should feel
  like walking away from an asset, not passing on an offer.
- **Honest scarcity of our attention.** The one true deadline we own is our
  own capacity and follow-up. "I am about to move on to the next builds this
  week", "this is the last time I will bring it up", "before I close this
  out". This is real (we do stop chasing), so it is fair to say. It also
  creates a Zeigarnik open loop, a small unfinished-decision itch, which a
  frictionless "yes or no is fine either way" then closes.

**Never fabricate scarcity.** No invented deadlines, no "only a couple of
spots left", no "a competitor in your space just signed with us", no fake
"other people are viewing this". These are lies, they break the
no-fabrication rule, and a sharp founder spots them instantly, which costs
more trust than the nudge was ever worth. Real loss, real ownership, real
limits on our time. Nothing invented.

**Avoid (cheesy or AI-flavoured phrasing, Raka 2026-08-19):** "I took a
proper look", "I did a deep dive", empty praise ("I was blown away",
"amazing business"), and the AI-tell adjectives and phrases specifically:
"stood out" / "really stood out", "spectacular", "genuinely distinctive" /
"distinctive", "strong" / "genuinely strong" / "a strong idea" / "reads
sharp" (as empty praise), "truly", "seamlessly", "not the easiest thing to make
tangible", "at the intersection of", "in today's world", "elevate", "level
up", "supercharge", "website journey", "game-changing", "revolutionise",
"unlock your potential", "seamless ecosystem", "move the needle", "how your
website should look", filler openers that flag a machine wrote them ("quick
reason", "here is why", "quick thought", "one thing", "here is the thing",
"the reason I say this"), generic AI slogans, overconfident claims about the
founder's priorities, jumping straight to a sales call when sending the
concept is the easier next step. A human business owner would not write
these; read every draft aloud and cut anything that sounds like a template
or a chatbot.

**Sounding human is structural, not just word choice (Raka 2026-08-29).**
The word blacklist above is necessary but not sufficient. A message with
zero banned words still screams AI if its *shape* is machine-shaped. What
actually gives it away, and the fix for each:
- **Template sameness across a batch.** If five openers all run
  praise then "one thing I noticed" then a consequence sentence then "we
  sketched a version" then "want me to send it over", the pattern itself is
  the tell, even though each is individually fine. Give every message a
  different shape: some open with the observation, some with a question,
  some skip the praise entirely, some lead with the offer. Never ship a
  batch that shares one skeleton.
- **Uniform sentence rhythm.** AI writes sentence after sentence of the
  same 15 to 20 word length. Humans mix a long winding thought with a
  three word punch. Vary it hard. Use fragments ("Want a look?" "Quick
  one.").
- **Contractions.** Real people type "you're, don't, it's, can't, I'd,
  won't, there's". Their absence reads formal and generated. Use them.
- **The consequence essay.** AI over-explains the mechanism ("so the
  buyers furthest down the funnel are the ones who bounce, without you
  realising"). A human states the problem and trusts the reader to feel
  it. Cut the explanation to a clause or drop it.
- **Rule of three / tricolons** ("faster, clearer, stronger";
  "Lloyd's, FCA, decades in marine"). Break the triad or make it messy and
  casual ("Lloyd's, FCA, the lot").
- **"Not X, just Y" and "not just A but B."** Overused by models. Avoid.
- **Bow-wrapped closers.** The neat aphorism that ties it up ("that
  defensibility and a simple next step are everything") is a model habit.
  End flat and plain, or on the ask.
The test: would a busy founder actually thumb this into LinkedIn on their
phone, or does it read like it was composed. If composed, rough it up.

**Pain agitation, done honestly (the neuroscience, Raka 2026-08-26).** The
amygdala processes a potential loss faster and roughly twice as hard as the
equivalent gain, but only when the loss is concrete, present tense and
specific. Abstract benefit ("this would help you get more clients") does not
fire it; a vivid, ongoing, named loss does. So the core of every opener is
one real problem, named plainly, then briefly *agitated* so they feel the
cost of it continuing, then relieved by the concept. This is the
Problem, Agitate, Solve shape, kept short and true.

- **Name the problem as an on-site observation, not a verdict.** Open the
  critique with "One thing I saw on the website is [X]" or "Wat me opviel op
  de site is [X]". It reads as a person who actually looked, not a pitch. It
  is also lower ego threat, so the defence goes down and the point lands.
- **Agitate the real cost, in the present tense, then stop.** One sentence
  that makes the loss concrete and continuous: who is bouncing, what they
  assume, what walks out the door *right now* because of that gap, and that
  the owner never sees it happen. "Right now someone comparing you to another
  agency hits that section, sees no proof, and quietly closes the tab, and
  you never find out they were there." Do not pile on, one vivid loss beats
  three vague ones, and over-agitating a small problem reads as manipulative.
- **Let them draw the conclusion (self-persuasion).** A light rhetorical
  turn ("so the visitors who were almost there never say anything, they just
  leave") makes the reader finish the thought themselves, which persuades far
  harder than us asserting it. Use once, not as a gimmick.
- **Every pain claim must be something actually verified on their live
  site.** Agitation amplifies a real problem; it never invents one. If the
  site is genuinely good with no honest gap, there is no pain to agitate,
  mark it NO_STRONG_ANGLE and move on rather than manufacturing hurt. Forced
  pain on a good business is both a lie and an insult.

### Getting a reply, reopening a stalled thread (the reply psychology, Raka 2026-08-27)
A message that gets no reply usually broke the mechanics of how people
decide to respond, not the writing. Our own dead follow-ups prove it: every
stalled thread here ended on a generic *"would love to hear more about what
you are building"* — no gift, no specifics, and a question that costs the
other person real effort to answer, so they don't. Reopen a quiet thread
with these honest levers, ideally most of them in one short message:

- **Reciprocity, give before you ask.** Lead with one specific, real thing
  they get for free: an actual observation about their site, a bug you
  spotted (a dead button, a blank stat), a genuine reflection of their
  situation. A free useful heads-up ("two of your buttons go nowhere right
  now") is a gift, and a gift creates a pull to respond. Opening with a
  request and no gift is the exact move that killed our follow-ups.
- **Label the situation, tactical empathy (Voss).** Name where they are or
  what they feel in a short "sounds like / I know that…" line, never
  accusatory and never a blaming "you". When someone feels understood they
  open up (the "that's right" moment). "Raising while you are heads down
  building is brutal" lands; "let me know if you need help" doesn't.
- **Mirror their own words back, consistency (Cialdini).** If they told us
  their goal, their plan, or a challenge, quote it back ("you said you wanted
  more brand clients", "your funding question stuck with me"). People act
  consistently with what they have already said out loud.
- **Answer what they actually said first.** If their last message asked us
  something (Happy asked about seed funding), address that honestly before
  any angle of our own, even if the honest answer is "not my area". Ignoring
  their question to pivot to our pitch reads as not listening, and kills it.
- **One open loop.** Reference one concrete thing that already exists and
  that they can only see by replying (a sketch, a specific fix, a version we
  built). The unfinished, unseen thing nags (Zeigarnik). It must be real,
  never a bluff.
- **One easy ask, near-zero friction.** End on a single question answerable
  in one word or a yes/no ("want me to send it?", "worth a look?"), or one
  calibrated "what/how" question that hands them control and pulls
  information ("what does your site do when a warm investor lands on it?").
  Never stack two questions, and never end on effortful homework like
  "tell me all about your business".
- **Preserve their autonomy, the "but you are free" effect.** A light,
  genuine "no pressure, totally your call, either way is fine" measurably
  lifts response rate, because it removes the feeling of being pushed. Say it
  and mean it. Never needy, never chasing.
- **Match their energy, length and language.** A one-line cool reply gets a
  short answer back, not a paragraph. Mirror their register.

These stack with the FOMO and pain-agitation levers above; the difference is
purpose. Those make them feel the cost of the problem; these make replying
feel easy, understood and worth it. A reopen that gives something real, names
their reality, and asks one effortless question is the shape that gets an
answer.

**Business outcome / cost of inaction:** the message should answer "so
what?" — comprehension, trust, conversion, enquiry quality, booking
completion, demo requests, partner qualification, fewer support questions,
less document chasing, fewer errors, less manual work. State the cost of
doing nothing when useful: founder time spent explaining, leads choosing a
clearer competitor, stalled partner evaluation, recurring manual
coordination, version mistakes, unqualified enquiries, capacity limits. Keep
it plausible and concise.

**Length. SUPERSEDED, see `docs/RULES.md`, the opener is 100 to 145 words.** Historical guidance below was ~90-150
words, shorter when one strong insight is enough. Don't cram every research
finding in — pick the one or two most accurate, commercially important,
curiosity-creating and visually demonstrable.

**Language:** default English for international ASTRA conversations; match
the prospect's language when evidence supports it; Dutch may be preferable
for Dutch owner-led businesses. "English only" was a preference in some
batches, not a universal rule.

**Historical connection opener** (pre-acceptance, not the post-acceptance
template above): *"Hi [Name], saw your business and thought it was cool 😀
I'm a business owner too! Would love to connect and share ideas! ☺️"* —
opened conversations successfully but is not the standard for detailed
post-acceptance outreach.

## 10. Learning ledger

ASTRA is meant to learn from corrections and responses. Classify replies as:
positive interest, curious but non-committal, objection, not relevant,
timing issue, no response, correction of ASTRA's understanding, referral to
another person. No response doesn't prove the message was wrong. One
positive reply doesn't validate a whole pattern. Founder corrections require
a research-process review, not just a copy fix.

### Recorded process failures (do not repeat these)

These are actual mistakes made on real prospects, kept here because each one
was invisible until it was caught, and each has a corresponding rule now
written into the relevant spec.

1. **The empty-shell trap → a factually wrong claim was sent.** A
   client-side rendered site returns HTTP 200 with a nearly text-free HTML
   shell, which reads exactly like a genuinely thin site. Greentic.ai was
   described in a *sent* message as a site that "stops at that one line"
   when it is in fact a full marketing site. The rule is now in
   `docs/enrichment-pipeline-spec.md` Stage 2: detect the shell, read the
   JS bundle, and only call a site thin once that is genuinely verified.
   **A negative claim ("they have no X") is the highest-risk claim type and
   needs a positive check of the actual routes, not a homepage inference.**
2. **A near-miss on the same class of error.** A draft told Infinity
   Biosciences their site "asks investors for a deck without naming a
   single person behind the work." Their `/about` carried a strong named
   team including the CEO and a named investor GP. Caught only because the
   page was opened before sending. Re-verify every claim immediately
   before drafting, never carry one forward from an earlier research pass.
3. **The wrong-domain trap, hit three separate times.** A plausible guessed
   domain, or one from a search result, resolves to a real but different
   company sharing the name: `prevent.de` → an unrelated `ias-gruppe.de`;
   `thesalesacademy.nl` → "Salespiration" by a different founder;
   `mapler.com` → a luxury hospitality brand, not Mapler AIx Inc. Confirm
   the fetched page actually names the right company, founder or product
   before using anything from it.
4. **Pitching a company that had already shut down.** Lums.ai served only
   "Lums.ai has closed." Check the site is a going concern before writing.
5. **Manufacturing a problem for a strong business.** Several accepted
   leads (D&Z Domotica, NOMW Health, dotega, Snorly) have real named
   testimonials, real client logos and no honest gap. Mark them
   `NO_STRONG_ANGLE` rather than stretching an invented friction into a
   pitch — a forced angle on a strong business reads as wrong or
   insulting, and books nothing.
6. **A dropped ball that cost 23 days.** Raka told Amir Matallaoui "I'd
   still love to send the concept over" and it was never sent. Anything
   promised in a thread is an open commitment; the inbox triage exists
   partly to catch these.
7. **Build-process scaffolding shipped on a client-facing prototype.**
   Captions reading "Stock, not a customer," `ILLUSTRATIVE` badges, figure
   numbers, and a dashed "PORTRAIT TO BE SUPPLIED" box all reached a
   delivered page. Each was individually defensible as honesty; together
   they turned a client website into an annotated internal document. Rule
   now in `docs/prototype-build-spec.md` I14: **treat the prototype as the
   production-final environment.**
8. **The same interactive bug shipped three times.** A CSS `display` rule
   overriding `[hidden]` broke panel switching on Rosalie, then Point
   Audit, then Greentic — despite the fix being written down after the
   first occurrence. A rule that is read and still missed needs an
   automated assertion, not a written reminder. Now a mandatory scripted
   no-JS check (spec F4).
9. **Inheriting a client's photo is not evidence of what it depicts
   (Connectome, 2026-08-18, caught by Raka before send).** Two images were
   taken from connectome.health and used as documentary proof of the client's
   own premises and staff: the interior was captioned "Inside the Connectome
   studio: a clinician and a client" and placed under the headline "The studio
   is open." On Connectome's own homepage those two images are **segment
   illustrations** inside the "Clinics and Preventive Health Programmes" and
   "Performance Environments" cards, carrying **no caption and no alt text**.
   The client makes no such claim; the prototype invented one. Every automated
   gate passed it, because provenance was checked and **depiction was not**.
   The rule, now in the build spec at D3: **for every photograph, find where
   the client themselves places it and what they themselves claim about it,
   and never make a stronger claim than they do.** Where the honest answer is
   "we do not have a photo of that," design a treatment (the fix here was a
   brand panel carrying only supportable facts), never a caption and never an
   invented depiction.
10. **"No such asset exists" asserted after searching one source
   (Connectome, 2026-08-18).** The build concluded that no photograph of the
   scanner, the headset on a person, or a real report screen existed anywhere
   public, and justified carrying the whole scan moment with drawn diagrams on
   that basis. Only connectome.health had been searched. Imperial College
   London's article on the partnership carried all three, including a person
   mid scan wearing the headset under the Connectome wall logo, and a full
   screenshot of the real platform. Rebuilding around them took the prototype
   from 89 to 94. **The client's own site holds brand assets; press coverage
   holds product, process and people photography**, because that is what
   journalists ask for. Rule now in the build spec at D3: search the client
   site, their press coverage, investor and partner announcements, any
   university or accelerator tie, and their socials, and record the result as
   "not found in <sources searched>", never as "does not exist".
11. **A deliberate pre-launch page critiqued as a broken one (Son
   Descolonges / TwinzClub, 2026-09-02, caught by the founder, not us).** The
   opener told Son his site "is the logo and the Private Equity Immobilier
   line, nothing an investor can read or do... someone serious finds an empty
   page and leaves." He replied "You don't read well. You have to put your
   E-mail to receive the news when the club will open. We have already a
   website." Two errors in one message: (a) twinz-club.fr is an intentional
   coming-soon / email-capture landing whose single job is to collect signups
   before the club opens, and it was diagnosed as a broken empty page; (b) it
   is not their real website, which exists elsewhere, so a launch teaser was
   critiqued as if it were the company. Both are the section 7 red-team
   question "Is the site intentionally serving another goal?" going unasked,
   this time at reply/opener time. A confident negative verdict about a choice
   the founder made on purpose reads as not looking properly and burns the
   thread. Rules now in `docs/inbox-triage-spec.md` Step 2 and Guardrails:
   **on any reply, pull the contact's whole thread before drafting (never off
   a truncated preview), and re-open the actual page to confirm it is not a
   deliberate waitlist/coming-soon landing and is actually their main domain
   before repeating or defending any website critique.**
12. **Researched blind and contradicted a prior verdict, then sent
   (2026-09-03).** A batch of recent accepts was researched from scratch
   without first reading `state/silent_accepted_queue.jsonl`, where earlier
   sessions had already logged verdicts on the same people. Two leads
   (Chris/ExpoCall, Fleur/DCCI) were sent openers that a prior row had marked
   `NO_STRONG_ANGLE`/skip (ExpoCall specifically: pitching website conversion
   to a conversion-automation founder is eye-roll risk), and OKOJU was
   re-derived wrongly as a "consultant" when a prior row had correctly
   identified it as a DTC cookware brand with a real early-access page. Rule
   now in `CLAUDE.md` (Silent accepted): **grep the queue and enriched_leads
   for a lead before researching or sending, and respect or explicitly
   override the prior verdict, never silently contradict it. The latest row
   per `leadId` is authoritative; supersede with a labelled note and dedup.**
13. **Blanket anti-pattern-8 hold missed a real credibility angle
   (PolyML, 2026-09-03, corrected on Raka's push).** PolyML was held
   `NO_STRONG_ANGLE` because "the website is not how deep-tech sells"
   (anti-pattern 8). That kills the conversion pitch, not the credibility one:
   a faithful render showed an abstract homepage over two stock photos with
   zero proof, for a company that had taken strategic industrial investment,
   so a partner or investor doing diligence lands on a research concept. The
   credibility reframe was a genuine send. Rule now in
   `docs/astra-commercial-angle-master.md` 31.2a: **anti-pattern 8 kills the
   conversion angle, not the investor/partner credibility angle; before
   holding a funded deep-tech lead, ask whether the site backs up where they
   actually are when their next investor checks it.**
14. **Held-pile verdicts (strong-site and blocked alike) were made without
   seeing the site (2026-09-03).** D&Z Domotica, Vimi Vino and Raven were
   parked as `NO_STRONG_ANGLE` or `BLOCKED` on a content read or a failed
   fetch. Actually looking (screenshot via a curl-mirror rendered offline in
   Chromium, or a human screenshot where a Cloudflare wall beat every tool)
   turned all of them into real sends: D&Z ran a ~2013 theme under strong
   content, Vimi Vino was a logo-only page behind an expired cert (no real
   site at all), Raven buried its award-winning work under pricing copy. Rules
   now in `CLAUDE.md` (Silent accepted): **a fetch failure is UNKNOWN and
   retryable via the render pipeline or a human eyeball, never "no angle"; a
   live domain can still be "no real website" (expired cert / logo splash /
   under-construction) which is a build opportunity; and roast the visual era
   before writing any site off.**

## 11. Prototype operating system (condensed)

Do not jump to a polished visual after a positive reply — verify business,
brand, audience, journeys and evidence first. Research before design: company/
model, audiences, the site's main commercial job, strongest friction,
category expectations, brand assets, facts safe to use vs claims to qualify.
Map each audience's entry point, main question, proof needed, desired
action, current friction, what happens after the click — don't give every
audience equal homepage prominence.

Avoid generic AI design (random gradients, glassmorphism, floating 3D
objects, abstract blobs, generic icon sets, symmetric card soup, generic
SaaS dashboards, stock imagery). Design should derive from the client's real
world, product, customers, industry — if only the logo and colours make it
identifiable, it's not personalised enough. Don't default to Arial/Helvetica/
Inter/Roboto unless the brand genuinely calls for it.

One complete customer journey beats many shallow pages. Score first drafts
1-10 on strategic accuracy, brand authenticity, journey clarity, visual
distinction, copy quality, believability, mobile experience, interaction
quality, commercial relevance, technical reliability — revise below 9/10 on
accuracy, authenticity or reliability.

**Superseded scoring note (2026-08-18):** the 1-10 scale above is the
historical version. The operative rubric is now the 100-point one in
`docs/prototype-build-spec.md` I15, shipping at **90/100 with zero hard
failures**. Where the two differ, the build spec wins.

**Three corrections that the condensed guidance above does not yet carry**,
each from a full audit round and each written up properly in the build spec.
Read them before building anything:

1. **Density, not just taste (spec Stage I).** "One complete journey beats
   many shallow pages" is still true, but it was being used to justify
   pages that were simply *thin*. Measured against Astra's own hand-built
   sites, prototypes were carrying 45% fewer sections, 75% fewer
   subsections, and zero working forms. There are now hard density floors
   per category. **Restraint removes something to strengthen what remains;
   emptiness is just missing material.** Minimalism has to be earned with
   volume behind it, not substituted for it.
2. **"Premium" is not absence (spec Stage I opening).** The default
   expression of quality — whitespace, desaturation, one grotesk, few
   assets — is the vocabulary of minimalist SaaS, not of the art, craft,
   trade and service businesses Astra actually sells to. Real reference
   sites in those categories are dense, saturated and characterful. A
   photographer's site carries ~79 images; a thin prototype gave one 11.
3. **The prototype is the production environment (spec I14).** Nothing on
   a delivered page may reveal it is a prototype: no `ILLUSTRATIVE` badges,
   no figure numbers, no provenance captions on photos, no "to be supplied"
   placeholder frames, no agency byline. A missing asset is a design
   problem to solve, not a caption to write. All disclosure moves to the
   internal rationale document, with at most one discreet production-normal
   footnote on the page itself.

Also note the visual-assessment counterpart on the research side: judging a
prospect's site now requires an actual **screenshot**, not just an HTML
read, because "looks like a PowerPoint from the 2000s" is invisible in
markup (`docs/enrichment-pipeline-spec.md` Stage 2a).

Standard deliverables: clickable prototype, desktop/mobile/deep-journey
previews, one-pager PDF, evidence register, research summary, complete ZIP.
Canonical storage: `Google Drive → Astra Agency → Startup → Client Mockups →
[Company Name] Mockup` (an older path used `Mockups` without `Client`,
treat `Client Mockups` as current but don't fork an existing project's
folder). File naming: `[Company]_Prototype.html`,
`[Company]_Desktop_Preview.png`, `[Company]_Mobile_Preview.png`,
`[Company]_Journey_Preview.png`, `ASTRA_[Company]_Direction_One_Pager.pdf`,
`[Company]_Evidence_Register.html`, `[Company]_Research_Summary.html`,
`[Company]_Prototype_Package.zip`. Confirm files exist before reporting
completion.

## 12. Outreach systems and campaign operations

This overlaps directly with `docs/enrichment-pipeline-spec.md` — that spec
is the concrete implementation of what this section describes. Key facts
worth carrying into pipeline decisions:

- The founder/new-business campaign targets people who started a business
  in 2026, prioritising no-website / placeholder / broken / weak sites.
  Website classifier categories (NO_WEBSITE / NOT_WORKING / PLACEHOLDER /
  BASIC / DECENT / STRONG / UNKNOWN) match the pipeline spec exactly,
  including the rule that an access failure is UNKNOWN, never NOT_WORKING.
- The completed 600-contact enrichment (`contacts-08-03-2026-enriched-
  complete.xlsx`) found: 424 verified 2026 launches, 41 basic/no-website
  opportunities, 29 safe to include, 168 manual review, 403 excluded.
- The accepted-connection outreach backlog (separate dataset from the
  600-contact campaign) stood at 132 accepted connections as of 1 August
  2026: 41 completed, 17 drafted/confirmed, 74 pending research. This is
  the same kind of backlog the inbox triage's Silent accepted tier now
  tracks in `state/silent_accepted_queue.jsonl` for v0.1 — treat them as
  the same ongoing problem, not two separate systems.

## 13. Named prospect intelligence (carry into outreach on these specific people)

Facts are dated, re-verify before acting, but the chosen angle and any
explicit correction from the prospect should not be re-derived from
scratch — several of these already appear in the inbox triage digest:

| Prospect | Business | Chosen ASTRA angle / correction |
|---|---|---|
| Gerard Ouattara — GOIA Technologies | Cyber-governance advisory for FCA-regulated IFAs | Snapshot-first trigger-led homepage with board-ready report preview. Declined for now (already redeveloping internally), stay in touch, don't push. |
| Jack Coulthard — On a Plod | UK running events | Jack was already rebuilding the site — a full redesign would be redundant. Angle is a modular partner-acquisition layer, not a new website. |
| Antanas Juodiskis / Pavlo Tyzhuk — Gravity Fellow | Deep-ocean energy storage, early-stage | Evidence-gated investor website. Never invent raise amount, valuation, investor commitments, or IP claims — everything is verified/company-reported/modelled/unresolved, label accordingly. |
| Lynn Chadwick / Steve Cooke — That Animation Company | 2D/3D animation studio | Lynn said the startup can't afford a full overhaul — standalone Production Partner page that fits inside the existing site, not a rebuild. |
| Isabela Tatu / Nicholas Abson — Clean Marine Shipping | Ship/municipal waste to fuel-cell power | Isabela explicitly said no budget for a full website, just wants the concept — circular-energy partner page, stage clearly labelled as engineering/lab work, not deployed infrastructure. |
| Andy Olson — Indigenous Fishers First | Fisheries strategy + modular cold-chain infrastructure | Community-owned seafood economy concept: community leads, infrastructure builds local decision rights/jobs/capability, not just equipment. |
| Terry Bordeleau — MRF FieldTech | Offline-first field ops for Indigenous land stewardship | After his reply, Raka wanted a chill, fun follow-up introducing broader ASTRA capabilities (not just the field-ops angle) and asking if anything else is relevant — don't reduce him to a single website problem. |
| Johannes Quandt — ROOBS | Medical-cannabis supply chain | Portal is nearly finished on his end — he actually asked about Netherlands market entry. That's a different opportunity (market entry, not portal-building); ASTRA should not pretend to offer regulated market-entry expertise without validation. |
| Stefan Janssen — Floorequa / Hulqua / W-floo / Calstrim | Floor-heating engineering/product ecosystem | Understand the distinct role of engineering/dimensioning vs product brands before suggesting a route. Outreach requested in English. |
| Fabrice Beauchêne — Glyx Therapeutics | Biotech | Site was under maintenance, blocking investor/partner assessment. Never invent clinical claims. |
| Amir Matallaoui — hoopooh | Classroom speech → evidence/reports/parent updates | Show the end-to-end teacher/parent workflow, not generic AI framing. |
| Daniel Shodamola — SewMyWears | Fashion-tech, bespoke clothing | Order-confidence flow (measurement checks, tailor verification, milestones, what happens if something goes wrong). |
| Natacha Waldmann — De Kade / Les Cabanes d'Ostende | Spans education, care and hospitality | Suggested centralised recruitment/matching route — revalidate scope, the org spans multiple activity types. |
| David Jonker — Open Foresight Hub / Perceptful.AI | AI platform | Research was requested to confirm whether the AI-platform angle is even relevant — do not assume it without renewed validation. |
| Rosalie Voortman — Voortman & Baumhauer | Wedding + brand photography | Site was wedding-led while she's moving into brand work — make brand photography a first-class route, not hidden. |
| Lisa Bouamra — Point Audit | Hospitality audit/QA software | Multi-property walkthrough concept, group dashboard to resolved issue. |
| Dr. Alan Ragueneau — GlisRisk | Non-financial risk quantification for Fortune 500 capital allocation | GlisRisk Connect Call was scheduled 7 August 2026, 12:30-13:00 CET. (Not the same person as Alan Sabin, the coaching prospect.) |
| Maarten Ectors — Greentic AI Ltd | Open-source "digital workers": deterministic, auditable AI workflows connected to real business systems | Asked for the prototype and received it (`astra-greentic-prototype.netlify.app`, 18 Aug). **The original opener's premise was wrong** — it claimed his site "stops at one line"; it is a full marketing site (see Learning ledger #1), so never repeat that framing. The angle that genuinely holds: the site says "Any Industry" and never names a buyer, a customer or a case study, and Maarten himself is invisible on it despite being a former **Chief Innovation Officer at Legal & General Group**, which is the strongest trust asset the company has. Two open asset requests if the conversation continues: a portrait of him, and one nameable customer. Deliberately not raised in the send message on Raka's instruction. |
| Aart Bos — TomatoWorld | Independent greenhouse-horticulture fieldlab: visitor experience, innovation fieldlab, partner ecosystem | Concept delivered July 2026: homepage separating the three competing audiences, plus a lighter guided-tour flow (the booking form currently mixes qualification and billing questions). Aart is warm but not the decision-maker — he forwarded to a new marcom colleague starting September and then **referred Joyce directly**. Do not re-pitch him; he has already done the internal selling. |
| Joyce van Dalen-Zwinkels — TomatoWorld | Operationeel manager: Operations, Events, Partnerships | Referred by Aart (12 Aug) who said she "was impressed" by the concept, contact `joyce@tomatoworld.nl`. She has not replied to two messages. The angle that is genuinely *hers* rather than marketing's: the guided-tour booking form mixes qualification with billing, which lands on operations, not on marcom. Ask small (fifteen minutes), and leave a September door open — that is when the new marcom colleague starts. |
| Antanas Juodiskis — Gravity Fellow | (see row above) | Additional 2026-08 note: he asked "What is your offer?" directly. Answered with an honest agency description tied to the investor-homepage concept rather than a generic capabilities pitch. |
| Lynn Chadwick — That Animation Company | (see row above) | Confirmed 2026-08-12: they had "just" committed budget elsewhere. Handled with a no-pressure reply; relationship preserved. Do not re-pitch on price. |
| Not-interested, closed gracefully (2026-07/08) | — | David Limousin (la Jeanette), Adam Amara, Stefan Janssen, Wouter Vermeulen, Ben Maicd, Ferdinand Witt-Dörring, Kenfack Leopold, Iman Javadi, Arbaaz Shaikh, Natacha Waldmann. All declined directly and all received a short, gracious close with an open door. **Standing instruction from Raka: even a "no" gets a reply — never let a thread just die out.** |

## 14. Alan Sabin — outcome lesson (not a prospect currently in the pipeline)

Extensive workshop/deck work was done for Alan Sabin's mental-health
coaching business (positioning, brand foundation, website/booking system,
growth funnel). Outcome: Alan chose a local social-media provider instead,
citing a preference for local providers generally (also true of his website
choice). **Lesson: excellent work and a positive relationship do not
guarantee scope.** Respond graciously, preserve the relationship, no
aggressive rebuttal — this is the tone model for any similar "we went with
someone else" reply.

## 15. Open decisions (do not treat as resolved)

Legal/operating structure between ASTRA, JMVentures and Amwisesa; exact
roles/equity/revenue split; canonical pricing sheet; Grow B maintenance
wording vs the €650/mo variant; pen-test price version (€17,500 deck vs
~€20,000 market note); whether revenue-share will ever be offered
(exploratory only so far); which social-media services ASTRA wants to sell;
long-term Lemlist → enrichment → message → campaign automation architecture
without n8n; whether the founder campaign stays multi-country/multilingual;
the canonical Drive folder name (`Client Mockups` vs older `Mockups`).

## 16. Instructions for any AI working on ASTRA (this repo included)

Read this context before acting. Search for newer Raka corrections and
apply them first. Verify person/company/role/website/date before writing
anything. Decide which of Grow/Optimise/Innovate/Build Squad actually fits
— or that none does. Separate facts, company claims, hypotheses and
unknowns. Red-team the analysis. Tie every recommendation to a realistic
business result, never promise traffic or numeric uplift without evidence.
Use "our agency." Keep outreach concise, specific, natural, useful. Prefer
"Want me to send it?" when a real concept exists — never claim ASTRA
sketched something that wasn't actually prepared or can't be delivered
immediately. Research brand/category before choosing any visual direction.
Build one believable journey, test on desktop and mobile. Keep strategy
commentary out of customer-facing work. Label assumptions, validate risky
claims. Preserve commercial version history, ask before quoting an
uncertain price externally. Learn from replies without overgeneralising a
single result. **If accuracy and speed conflict, choose accuracy.**

## 17. Final operating principle

The goal is not to send the most outreach or generate the prettiest
mock-up. The goal is to make carefully chosen prospects think: *they already
understand something important about our business, and they showed what
they could improve before asking for a meeting.* Research deeply. Challenge
conclusions. Be selective. Give value first. Show rather than claim. Learn
from every result.

## 18. Commercial angle selection

How to research a lead deeply enough to diagnose it is governed by **`docs/astra-prospect-research-master.md`** (Layer 2, research). Which problem to then raise is decided by  **`docs/astra-commercial-angle-master.md`**, the canonical angle-reasoning playbook. Sections 4 (this doc) name the service lines; that file decides which one actually fits by diagnosing the bottleneck, scoring candidate angles, and returning `NO_STRONG_ANGLE` when nothing meaningful is evidenced. Read it before choosing an angle; read this doc for who ASTRA is and how to word it.

## 19. Writing standard (anti-AI)

The voice rules in section 9 say what to write. **`docs/writing-standard-anti-ai.md`**
governs how it reads so it never sounds machine-generated. Read it before
drafting any message, reply, prototype line, or brief. The non-negotiables:
no em dashes; no "you're absolutely right" / "good catch" / "great question"
validation; no "honestly" or "to be honest" theatre; no "it's not X, it's Y"
structures; no forced groups of three; no corporate fog (drive value,
seamless, robust, leverage, unlock, elevate); no throat-clearing openers ("I
came across your profile," "I'd love to hop on a quick call"); no generic
uplift endings. Say the specific thing about their actual business and stop.
