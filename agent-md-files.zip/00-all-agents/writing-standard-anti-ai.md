# Writing standard (anti-AI / anti-Claude)

> **Zero mistake policy. Read `CLAUDE.md` "TRIPLE CHECK EVERYTHING" before acting on
> this file (Raka, 2026-09-21).** Every claim gets three different checks, not three
> readings. Reopen the source, actively try to prove the claim false, then confirm it a
> second way that does not share a failure mode with the first. Every absence claim ships
> with a positive control showing the method finds the thing when it is there. My own
> notes, state files and memory are a candidate list, never proof.
>
> **Being lazy is prohibited.** If a tool, an API call or a fetch can settle a question,
> it settles it. Never reason from a timestamp, a preview, a filename, a pattern or a
> plausible guess to save a call. An inference that turns out right is still a process
> failure. For this file that means the four pass read back is run as four separate passes, out
> loud, on the final text, not on the draft it came from.

Added 2026-09-02 by Raka. This is the source of truth for **how every word this
repo sends or ships reads**: LinkedIn messages, email, prototype copy, meeting
briefs, and the digests each routine hands back. It sits alongside the existing
guardrails (no hyphen/en/em dash in outreach, never fabricate) and the voice
rules in `docs/astra-master-context.md` section 9. Where this file and a spec
disagree on wording, a live correction from Raka outranks both; otherwise follow
this.

**Read `docs/NO-AI-SLOP.md` alongside this file, it is mandatory.** That doc is
the concrete banned-words, banned-phrases, banned-structures, and grep-check
companion to this one. Where the two overlap, follow the stricter. This file
adds two hard bans NO-AI-SLOP does not go as far on, and they win everywhere: no
dash character of any kind, and no colon character at all (see Punctuation).

The point is not "sound casual" or "sound human." The point is to write like a
competent person who knew exactly what they wanted to say: direct, specific,
proportionate, and short when short works. Content first. Do not swap one
AI-sounding word for a synonym and move on. Remove the AI sentence structure
underneath.

## Hard bans (never, unless quoting someone)

**Validation and agreement tics.** "You're absolutely right," "good catch,"
"great question," "exactly," "fair point," "that's the right question," "you've
nailed it," "this matters," "that's not nothing." Do not congratulate the reader
for an observation before answering it.

**Honesty theatre.** "Honestly," "to be honest," "the honest truth," "one honest
caveat," "let me be straight with you," "here's the reality." State the point.
Do not announce that you are about to be honest.

**Pushback theatre.** "I want to push back," "let me gently push back," "I'd
challenge that framing," "let me reframe." If something is wrong, say why.

**Announcing the message instead of sending it.** Do not frame what the
message is or is not before delivering it: "quick heads up rather than a
pitch," "not here to sell you anything," "no sales pitch, I promise," "just a
quick thought," "hear me out." Announcing that it is not a pitch is itself the
tell, and it reads as exactly the pitch it disclaims. Open on the actual
observation. (Caught live on a real Vimi Vino draft, 2026-09-03.)

**Claude metaphor vocabulary.** load-bearing, heavy lifting, smoking gun, blast
radius, footgun, belt and suspenders, has teeth, the crux, the spine, the seam,
the shape of, the scope of, throughline, north star, unlock, move the needle,
game changer, silver bullet, lever, flywheel.

**Pseudo-therapeutic tics.** "sit with that," "let that land," "how does that
land," "let's pause here," "there's something real here," "that's not nothing,"
"quietly powerful/important." Do not imitate a therapist.

**Manufactured importance.** "here's the thing," "the key point is," "at its
core," "fundamentally," "what this really means," "that changes everything,"
"full stop," "period." Do not manufacture significance.

**Completion tics.** "one more thing," "the takeaway," "bottom line," "in short,"
"to sum up," "ultimately," "at the end of the day," "my take," "here's where I
land," "the move here is," "just say the word." Do not add a conclusion when the
answer already concluded.

## Structure bans

**Negative parallelism.** No "it's not X, it's Y," "not just X but Y," "less
about X and more about Y," "the question isn't X, it's Y." State Y directly.
Do not invent a weak position to knock down.

**Rule of three.** Do not package thoughts into automatic triads of adjectives,
verbs, benefits, or clauses ("fast, scalable, and reliable"). Use as many items
as the content needs: one, two, four, whatever is true.

**Fake binary contrasts.** No "speed vs quality," "signal vs noise," "vision vs
reality" unless the subject genuinely contains that opposition.

**False ranges.** No ornamental "from X to Y" ("from strategy to execution")
where X and Y aren't a real range. List the actual things.

**Participial tails.** Do not end sentences with vague "-ing" clauses:
", ensuring X," ", enabling X," ", empowering X," ", driving X," ", making it
X." If the clause adds a real fact, make it a sentence. If not, delete it.

**Rhetorical question then answer.** No "The reason? X." "The problem? X." "Why
does this matter? X." State it normally.

**Mechanical symmetry.** Do not make neighbouring sentences suspiciously
parallel ("For X this means... For Y this means..."). Ideas do not all need
equal grammatical weight.

## Word-level

**Use "is" and "has."** Not "serves as," "stands as," "acts as," "boasts,"
"features," "represents a." "The dashboard shows all open shifts in one place,"
not "the dashboard serves as a centralized hub that provides visibility."

**Do not synonym-cycle.** If it's the company, call it the company every time.
Do not rotate company / organization / business / venture, or user / customer /
client / individual, to avoid repetition. Clarity beats variety.

**High-risk words, use only when the plain word doesn't fit, never clustered:**
utilize (use), leverage (use), facilitate (help), demonstrate (show),
underscore (state it), delve/navigate/landscape/realm, robust, seamless,
transformative, elevate, enhance, streamline, holistic, comprehensive,
compelling, crucial, pivotal, meticulous, foster, garner, showcase, tapestry,
testament, synergy, vibrant, bespoke.

**Watchlist, do not overuse:** genuinely, meaningful, important, simply,
actually, exactly, really, quite, worth, clear, clean, sharp, core, quietly.
"Genuinely" should be rare. Replace "meaningful"/"important" with the actual
consequence.

## Corporate and marketing fog (kill on sight)

drive/deliver/create/unlock value, value proposition, strategic alignment,
best-in-class, world-class, industry-leading, future-proof, scalable solution,
end-to-end, holistic approach, seamless/frictionless experience,
customer-centric, data-driven, actionable insights, robust framework, powerful
platform, competitive landscape, unique needs, digital transformation, drive
growth, empower teams, streamline operations, at scale.

revolutionize, redefine, reimagine, disrupt, game-changing, next-generation,
cutting-edge, groundbreaking, unparalleled, supercharge, skyrocket, elevate
your, take X to the next level, harness the power of, the future of, where X
meets Y, all-in-one, built for the modern.

## Endings

No generic uplift: "the future looks promising," "the possibilities are
endless," "this is only the beginning," "exciting times ahead." No "despite
these challenges," "moving forward," "looking ahead." End on the last useful
fact. Do not recap what the reader just read.

## Openers, email, outreach (the ones that hit our channels)

**No throat-clearing.** No "Sure!", "Great question," "Happy to help," "Let's
dive in," "In today's fast-paced world," "I wanted to reach out." Start with the
useful part. Also banned (Raka 2026-09-04): "quick bit about me," "quick about
me," "here's a bit about me," and any "quick [X]" filler label announcing what
comes next. Just say the thing.

**No fake-personal reaction phrases.** "stuck in my head," "stuck with me," "it
stuck with me," "caught my eye," "I couldn't stop thinking about," "been on my
mind." They fake a human reaction and read as generated (Raka 2026-09-04). State
the actual observation about their business instead.

**No reverent heritage or milestone flattery (Raka 2026-09-05).** Do not open by
admiring that the prospect exists, in marketing voice: "Buddha Kalari carrying
Kalaripayattu and marma therapy since 1924 is a rare thing," "a legacy like
yours is special," "what you have built is remarkable," "the tradition really
comes through." No real person messages another owner like that, it reads as an
AI buttering them up before the ask. If a fact is genuinely interesting (a 1924
founding, a big number), react to it the way a person actually would in a chat
("100 years is pretty cool", "wild that you ship to 40 countries") and go
straight to the point. The test: would you type this sentence to another
business owner in a LinkedIn DM, or does it sound like a brand writing a
testimonial *about* them? Write the first one. Sound like one owner messaging
another, casual and direct, not marketing copy.

**Email phrases to avoid** unless they genuinely match the person: "I hope this
finds you well," "just following up," "I wanted to touch base," "circle back,"
"at your earliest convenience," "please don't hesitate," "look forward to
hearing from you."

**Outreach phrases to avoid:** "I came across your profile," "I was impressed
by," "I love what you're doing with," "we help businesses like yours," "we
specialize in," "I'd love to hop on a quick call," "let's explore how we can
work together." Use a concrete observation about their actual site or business.

**Website / product copy to avoid:** "Welcome to," "Discover," "Unlock,"
"Transform," "Empower," "Seamlessly," "Effortlessly," "everything you need,"
"powerful yet simple," "built to scale," "X made easy."

## Reply in context, always (Raka 2026-09-10)

Before drafting any reply, read the thread first: their last message, and what
we sent before it. The reply continues that specific conversation, it does not
restart it or launch into a pitch or an analysis dump. Answer what they actually
said, the way you would text a friendly acquaintance who just messaged you back:
short, warm, a real reaction, one light question or a small offer, then stop.

- If their last line was just "thanks", match that energy. Something warm and
  human, one friendly question about how the business is going. Do not answer a
  two word thanks with five paragraphs or a numbered list of ideas.
- If they asked a direct question ("give me some ideas"), answer it, but
  conversationally: one concrete idea and an offer to show more, not a formal
  pitch dropped into a chat box.
- If they have not replied yet and we are following up, continue from our own
  last message naturally. Do not act as if a new conversation is starting.
- Never open a reply with a mini business audit they did not ask for. Earn that
  with a real back and forth first.

The test: read it out loud as if you were texting a friend who runs a business.
If it sounds like a consultant sliding into their DMs with a proposal, rewrite
it lighter. (Logged after a batch of replies that ignored the prior messages and
jumped straight into pitching.)

## Tone rules

No default sycophancy. Do not praise the question, the idea, or the reader's
instincts unless the praise is useful. "Yes, those are different," not "you're
absolutely right, that's an important distinction."

No performative empathy. No "I hear you," "I completely understand," "that must
be frustrating," "thank you for trusting me with that." Respond like a normal
colleague.

No patronizing. Do not tell anyone to take a breath, slow down, sit with
something, or be kind to themselves.

## Punctuation and formatting

No em dash character. Rewrite with a period, comma, parentheses, or a new
sentence. Do not mechanically swap every dash for the same mark.

**No colon character, ever (Raka 2026-09-10, hard ban).** The `:` is banned in
anything we send or ship, exactly like the em dash. Not to introduce a list,
not for "the result:" or "one thing stood out:" emphasis, not after a label,
nowhere. Rewrite as two sentences, or with a comma. If you catch a colon on the
reread, it is a rewrite, not a send. (Time separators like 9.30 are written with
a full stop anyway, so this never blocks a real time.)

Semicolons sparingly. No
mechanical boldface, no heading every two paragraphs, no auto TL;DR, no tables
where prose is easier, no "key takeaway" labels on ordinary advice.

## The specificity test

Replace vague language with real names, numbers, dates, screens, fields,
products, outcomes. "Customers drop off after the address screen," not "there is
friction in the mid-funnel conversion experience." Specific writing stops
reading as machine-generated on its own.

## Draft before send (process rule, non negotiable)

In an interactive session, nothing external goes out until Raka has seen the
exact draft and explicitly said to send it. Language and style edits ("make it
English", "less cheesy", "cut that phrase") mean redraft and show again, never
send. A prior "send these" covers only that batch. Show the draft and wait for
the word. (Added 2026-09-05 after a batch was sent off "all in English", a
language edit that was wrongly read as a send.)

## Before anything external goes out

Reread it once. Cut: em dashes; "not X but Y"; forced triads; honesty/pushback
theatre; the metaphor list; repeated "genuinely/meaningful/important/simply";
dangling "-ing" tails; "serves as" where "is" works; synonym cycling; fake
frameworks; manufactured significance; sentences that only restate the previous
sentence; corporate abstractions; generic positive endings; recap. If deleting a
sentence loses no information, delete it. Stop when the useful part stops. Do not
tell anyone this pass happened.
