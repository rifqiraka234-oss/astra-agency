# Astra Agency — Automated Enrichment Pipeline (Claude Code build spec)

> **Zero mistake policy. Read `CLAUDE.md` "TRIPLE CHECK EVERYTHING" before acting on
> this file (Raka, 2026-09-21).** Every claim gets three different checks, not three
> readings. Reopen the source, actively try to prove the claim false, then confirm it a
> second way that does not share a failure mode with the first. Every absence claim ships
> with a positive control showing the method finds the thing when it is there. My own
> notes, state files and memory are a candidate list, never proof.
>
> **Being lazy is prohibited.** If a tool, an API call or a fetch can settle a question,
> it settles it. Never reason from a timestamp, a preview, a filename, a pattern or a
> plausible guess to save a call. An inference that turns out right is still a process
> failure. For this file that means launch status, site state and campaign status are refetched
> every run, and no row is carried forward on the strength of an earlier run's
> verdict.

> Source of truth. This is the spec as provided by Raka. `CLAUDE.md` at the repo
> root is the operating playbook derived from it — if the two ever disagree,
> this file wins and `CLAUDE.md` should be corrected to match.

## Purpose
Take a raw contact list (new business sign-ups) and produce the same quality output already proven in `contacts-08-03-2026-enriched-complete.xlsx`, but as a repeatable, unattended, resumable script instead of manual chat-driven research. Output feeds directly into lemlist via its native import tools.

## Input
Do not source new contacts from a manually exported/uploaded CSV or XLSX for the recurring run. That creates a local file dependency, which blocks running this as a Cloud Routine (Anthropic's cloud-hosted scheduled agent runs against a fresh environment each time and cannot read files sitting on Raka's machine). Instead, each run should query lemlist directly via its API for contacts added since the last run (lemlist's contact/lead endpoints support filtering by added date). This keeps the whole pipeline API-driven end to end: pull from lemlist, enrich via web research, write back to lemlist, with no manual export/upload step ever required.

A manually provided CSV or XLSX (matching the "Source Data" sheet shape in the reference file, minimum fields firstName, lastName, companyName, companyWebsite, linkedinUrl) remains a valid input only for one-off manual test runs while building and validating the pipeline, not for the recurring automated run.

## Deployment: Cloud Routine, not local
Build and run this as a Claude Code **Cloud Routine**, not a local/desktop scheduled task. Reasoning specific to this pipeline: it is fully API-driven (lemlist API for contacts and campaign import, web search/fetch for research), it has no dependency on local files once sourced via the API as above, and cloud is the only mode that runs without Raka's machine being on, which is required to actually deliver "I don't need to do anything." Local scheduling would only be the better choice if the pipeline needed local-only files or tools, which it does not.

## Input pre-filter (token saving, do this before any AI call)
The real raw export (e.g. `contacts-08-02-2026.csv`) has 75 columns per contact. Most are empty lemlist internal tracking fields (signal data, campaign history, hubspot IDs) that are never used by this pipeline and should never reach a research or generation call. Before Stage 1 runs, strip every row down to this minimal object:

```
firstName, lastName, companyName, companyWebsite, linkedinUrl, jobTitle,
companyLocation (fallback to location if empty), companyFoundedOn,
companyDescription, companyIndustry
```

That is 11 fields instead of 75, roughly an 85% reduction in per-contact payload before enrichment even starts. Drop the rest at the file-reading step, do not carry them through the pipeline or write them back out.

Two of these kept fields double as a cost saver, not just context, because they are pre-populated by lemlist's own lighter enrichment on most rows (checked against a real batch: `companyFoundedOn` populated on 577/600 rows, `companyDescription` on 588/600):
- `companyFoundedOn` — treat as a starting hypothesis for Stage 1, not a verified fact. When present, do a lighter confirm-or-flag check (does other evidence agree or conflict) instead of a full from-zero search. Still never treat it as HIGH confidence without at least one independent check, lemlist's own auto-enrichment can be wrong.
- `companyDescription` — treat as a starting hypothesis for the company purpose used in Stage 4's opener. When present and it reads as genuine (not templated boilerplate), it can save a research call. Always sanity-check it against the live site rather than quoting it verbatim, it is company-reported, not verified.

This pre-filter and hint-reuse is the main lever for keeping the pipeline cheap at hundreds of rows. Do not skip Stage 1/2 verification entirely just because a hint exists, the hint only reduces how much fresh research is needed, it never replaces the confidence check.

## Per-contact pipeline (the loop)
For each contact, run through these stages. Checkpoint after every contact (write progress to disk / a resumable state file) so a 600-row batch can be interrupted and resumed without repeating work or burning duplicate API calls.

### Stage 1 — Business launch verification
- Search for confirmation of when the business actually started (founder announcement, incorporation date, "we launched" language, LinkedIn company page creation date).
- Output fields: `businessLaunchStatus` (QUALIFIED / UNVERIFIED / DO_NOT_USE), `businessStartDate`, `businessLaunchConfidence` (HIGH/MEDIUM/LOW), `businessLaunchSource`.
- Compute `howLongAgoBusinessWasCreated` using this fallback ladder, so a missing exact month doesn't block automation on its own:
  - **Exact month/date confidently found** → use the precise phrase ("6 months ago", "in March"). `businessLaunchConfidence = HIGH`.
  - **Clear evidence the business is genuinely new/recent (this year, "just launched," a fresh LinkedIn company page, a founder's "I started my own thing" post) but the exact month isn't pinned down** → use `"recently"` instead of guessing a month. `businessLaunchConfidence = MEDIUM`. This is still eligible for Tier 1 auto send, since "recently" makes no specific claim that can be wrong.
  - **No real evidence the business is new at all** → `businessLaunchStatus = DO_NOT_USE`. Do not send a launch congratulations of any kind, vague or specific. This is the only case that still blocks the connection invite, and it should route to manual review rather than being silently dropped.
- Rule: the ladder exists so "I don't know the exact month" and "I don't know if this business is even new" are never treated the same. Only the second one should slow anything down.

### Stage 2 — Website classification
- Visit the actual site (not just search snippets — load real pages).
- Classify into exactly one: NO_WEBSITE, NOT_WORKING, PLACEHOLDER, BASIC, DECENT, STRONG, UNKNOWN.
- Critical rule: if the site can't be accessed (bot-blocked, timeout, JS-only render failure), classify UNKNOWN — never NOT_WORKING. A research-environment access failure is not evidence the site is broken.
- **The empty-shell trap (this caused a factually wrong claim in a real sent message, 2026-08-17 — read this before writing any "the site is thin" observation).** A client-side rendered site (React, Vue, Next in SPA mode, Lovable, Framer, many Webflow-adjacent builders) returns **HTTP 200 with a small, valid, nearly text-free HTML shell**. This does not look like a failure. It looks exactly like a genuinely thin or placeholder site, and it will happily pass a naive fetch as "this company has one line of copy on their homepage." Confirmed cases in this project: greentic.ai (a full marketing site with an architecture explainer, competitor comparison, five use cases and a partner page, which fetched as a bare shell and was described in a *sent* message as "the site stops at that one line"), barkerlonghorn.com (1.4KB shell, actual product copy sat in a 476KB JS bundle), and Elevate Marketing. Before classifying anything as PLACEHOLDER/BASIC or writing a thinness observation, confirm the emptiness is real:
  - Check for the tell: a tiny body, a `<div id="root">`/`<div id="app">`, a `<noscript>` line like "You need to enable JavaScript to run this app," and a `<script src="/assets/…js">` or `/static/js/main.*.js` reference.
  - If present, **fetch the JS bundle and read the copy out of it** (`curl` the bundle, then grep for long human-readable strings) and/or check the served JSON-LD, `<title>` and `<meta name="description">`, which are usually rendered server-side even on an SPA and often reveal a fully-developed business.
  - Only conclude "thin" once the rendered/extracted content is genuinely thin. If the content cannot be extracted at all, that is **UNKNOWN**, not PLACEHOLDER, and the contact does not get a thinness-based pitch.
  - Same discipline applies to a screenshot for Stage 2a: a full-page screenshot taken before lazy-loaded images and webfonts resolve will show blank regions that are an artifact of the capture, not a defect in the site. Force images eager, scroll the full page, and wait for fonts before judging (this exact artifact produced a false "5 of 11 images broken, gallery blank" reading during an internal audit).
- Capture one specific, verified observation of what's actually wrong (not generic — e.g. "template Latin copy still visible on the About page", not "could look more professional"). Store as `verifiedWebsiteObservation`.
- **Every claim that will appear in a sent message must be re-checked against the live site immediately before drafting**, not carried forward from an earlier pass. A claim about what a site does *not* have ("no team page", "no pricing", "no case studies") is the highest-risk kind and needs a positive check of the actual routes and page content, not an inference from a homepage read. The near-miss precedent: a draft claimed Infinity Biosciences "asks investors for a deck without naming a single person behind the work," and the `/about` page in fact carried a strong named team including the CEO and a named GP investor. It was caught only because the page was opened before sending.
- Output fields: `websiteAnalyses` (the classification), `websiteOpportunity` (HIGH/MEDIUM/LOW/NONE), `websiteAnalysisConfidence`, `websiteAnalysisSource`.

### Stage 2a — Visual assessment (confirmed by Raka, 2026-08-18: screenshot the site, don't just read it)

Reading a site's HTML/text answers whether the *content* is there. It cannot answer whether the site *looks* dated, generic, and amateur, which is often the real reason a business owner is a good prospect and is exactly the signal this stage exists to catch. **Take an actual screenshot (desktop width, full page or at minimum the fold) and look at it before finalizing the classification.** A site can read as content complete in Stage 2 and still be visually a decade out of date, this stage is what tells the two apart.

Raka's own framing: this should look for sites where "the colours and fonts and pictures and shapes are simple, there's no art in it, no dynamic aspect of it, it looks like something from the 2000s." His shorthand for the failure mode: **"it looks like PowerPoint on a website."**

Judge the screenshot against this checklist. Each yes pushes toward BASIC/DECENT with a real, visually specific `verifiedWebsiteObservation`, not a vague "needs a refresh":

- **Palette** — one brand colour plus white/grey and nothing else, no depth, no secondary or accent tones, flat and uniform across every section. Compare against a real single-accent palette used deliberately (Hermod's navy/red/cream, Alan's chocolate/cream/orange) — the dated version has no *reason* behind the colour, it is just "the logo colour, everywhere."
- **Typography** — a single generic system/default sans (Arial, generic web-safe sans) used identically for headings and body, no pairing, no personality, no scale variation beyond bold and bigger. Real type choices commit to something; dated sites default to whatever the builder tool shipped with.
- **Imagery** — generic stock photography (handshake, office building, aerial road/infrastructure shots, generic "team smiling at camera" stock), or real photos that are amateur snapshots with no art direction (flat lighting, no composition, no consistent treatment across the page). Either way: pictures that could belong to any company in the category, not this one specifically.
- **Shapes and layout** — a rigid grid of equal boxed cards with hard drop shadows and small corner radii, icon-in-a-circle or icon-in-a-hexagon repeated identically down the page, symmetric centered layout throughout, no full bleed moments, no asymmetry, no layered or overlapping elements. This is the literal "slide layout" feel: title, then a row of boxes, then another row of boxes.
- **No dynamic aspect** — zero motion, zero hover states beyond a colour swap, no scroll based reveal, no interaction of any kind beyond clicking a nav link or a button. The page behaves exactly the same on every visit, nothing about it feels alive.
- **The gut check** — if it were exported from a corporate PowerPoint template and each slide became a section, would this page look meaningfully different? If the honest answer is no, that is a BASIC/DECENT classification with a strong redesign opportunity, and the specific visual failure (not "looks old" but which of the five signals above) goes into `verifiedWebsiteObservation`.

This is a positive signal for the pipeline, not a criticism to soften: a site matching several of these is exactly Astra's ideal client profile, a real business with real content that has never had real art direction applied to it. Score it plainly and specifically, the same way Stage 2's text-based rule already requires for functional issues.

Add `visualAssessment` (one to three of the checklist signals actually observed, named specifically) alongside the existing Stage 2 output fields, and let it inform `websiteOpportunity` the same way the functional read already does.

### Stage 3 — Eligibility decision
Combine Stage 1 + Stage 2 into `campaignEligibility`:
- **INCLUDE**: launch verified AND site is NO_WEBSITE/PLACEHOLDER/BASIC (a defensible gap exists).
- **MANUAL_REVIEW**: plausible fit but launch date OR website read is uncertain enough to need a human check before sending.
- **EXCLUDE**: wrong entity, not a recent launch, competitor, or already a strong/decent site with no real angle. Set `exclusionReason`.

### Stage 4 — Message generation
Only for `campaignEligibility = INCLUDE`. Generate both messages using these exact templates (do not deviate from structure or tone):

**Connection invite:**
```
Hey [name], congrats on launching [company] [x] months ago, exciting times! I'm a business owner too, would love to connect and share ideas :)
```
- `[x] months ago` is replaced by whatever Stage 1's fallback ladder produced: a precise phrase ("6 months ago") when the month is known, or the word "recently" when the business is confirmed new but the exact month isn't (i.e. `[x] months ago` becomes just `recently`, so the line reads "congrats on launching [company] recently, exciting times!"). Never fabricate a specific month that wasn't actually found.

**SUPERSEDED 2026-09-21. The opener is 100 to 145 words, per `docs/RULES.md`.** The 65
word ceiling below was correct for the August template and is kept for the record, but
three documents carried three different numbers and two each claimed to outrank the other.
`docs/RULES.md` is now the single source and it says 100 to 145. Read the rest of this
section for the structure, not for the length.

**First message (historical 65-word ceiling, no longer the operative number):**
```
Hey [name], thanks for connecting. I had a look at [company], and [specific genuine synthesis of what they do, framed as a real strength, not a generic paraphrase].

However, [specific structural problem], so [who is affected] can't easily [what becomes harder as a result].

Our agency sketched [specific named concept] that [what it does]. Want me to send it over?
```
This is an expanded version of the original 50 word template, raised to 65 words based on analysis of a real message that performed well (the Andy Olson / Indigenous Fishers First send). The structural upgrade from the original template: the opener leads with a genuine, specific synthesis rather than a bare "[company purpose]" restatement, and the roast clause now includes who is affected and what becomes harder, not just the flaw itself, this is the "so what" that makes the message feel considered rather than templated. Do not let this become an excuse to write a generic 107 word essay like a first draft might, the ceiling is real and every clause should still earn its place.

- `[specific genuine synthesis]` — one sentence that proves real understanding of the business, framed positively (a sharp angle, a genuinely novel approach, whatever is actually earned by the research), pulled from real findings not boilerplate. Never reach for "amazing" or "novel" as filler, only use that framing when the business genuinely is doing something distinctive.
- `[specific structural problem]` — pulled directly from `verifiedWebsiteObservation`, one specific issue only.
- `[who is affected] / [what becomes harder]` — name the actual person or role who hits friction (a buyer, a funder, a visitor trying to do X) and the concrete decision or action that gets harder as a result. This is the cost of inaction, tie it to the business's actual goal where possible (a sale stalling, a funder hesitating, a buyer going to a competitor), keep it to one clause.
- `[specific named concept]` — name the actual thing sketched (a project readiness flow, a buyer journey homepage, whatever fits), not "a better version of your site."
- Given the 65-word ceiling with several variable slots: if it doesn't fit, trim the cost-of-inaction clause down to its shortest real form before cutting the opener or the roast, those two carry the most weight.
- Never use hyphens, en dashes, or em dashes (-, –, —) anywhere in either message, in any field feeding into them, or in any generated text that touches a sent message. Rewrite around the dash instead of substituting a comma or colon if it changes meaning. Separate any multi sentence output with clear spacing, not run on clauses.
- For voice, preferred/avoided wording, and the "our agency" framing, `docs/astra-master-context.md` section 9 is authoritative and goes deeper than this spec, read it before drafting if this is a new session. That doc's general outreach-message length guidance is 90-150 words, this 65-word ceiling is a tighter, confirmed override for this specific first-message template (2026-08-12), the tighter number wins here per the truth hierarchy, not the general guidance.

### Stage 5 — Write results
Append only the fields this pipeline actually generates back to the working file/state, do not carry the original 75 column row through: `firstName`, `companyName`, `businessLaunchStatus`, `businessStartDate`, `businessLaunchConfidence`, `businessLaunchSource`, `howLongAgoBusinessWasCreated`, `websiteAnalyses`, `websiteOpportunity`, `websiteAnalysisConfidence`, `websiteAnalysisSource`, `verifiedWebsiteObservation`, `visualAssessment`, `campaignEligibility`, `exclusionReason`, `connectionMessage`, `firstMessage`, `researchDate`. Keep this write back schema stable and minimal so progress files and lemlist import payloads stay cheap at hundreds of rows, same schema as the reference `Enriched Leads` sheet, minus the noise columns.

## Batch orchestration
This pipeline should be built and deployed as a Claude Code **Routine** (the cloud hosted, scheduled agent feature), not a one off script you run by hand each time. A Routine runs unattended on a schedule without needing your computer on, which is the actual mechanism that makes this "I don't need to do anything." Do not use the lightweight CLI `/schedule` or `/loop` session scoped tasks for this, those are meant for short lived polling and auto expire after 7 days, which would silently stop this pipeline without warning.

Recommended cadence: **once daily**, not hourly or continuous. Reasons: it matches the weekly Tier 2 batch review rhythm below, it keeps LinkedIn sending volume steady and human paced rather than bursty (a real account safety concern for automated LinkedIn outreach), and it gives a natural daily checkpoint for the spot check step.

- Process contacts sequentially or in small parallel batches (respect rate limits on search/fetch).
- Persist a checkpoint (e.g. last completed row index or a per contact status file) so a crashed or interrupted run resumes cleanly rather than reprocessing or duplicating spend.
- Log failures per contact (e.g. site totally unreachable after retries) with reason, rather than silently skipping.
- At the end of a run, produce a summary: total processed, INCLUDE count, MANUAL_REVIEW count, EXCLUDE count, failures.

## Custom field names (critical, must match exactly)
The lemlist campaign sequence references two lead custom fields directly via Liquid syntax:
- `{{connectionMessage}}` — the connection request step
- `{{firstMessage}}` — the first message step (+1 day after acceptance)

Code must write generated message text into custom fields with these EXACT names when importing/updating a lead (`import_leads_to_campaign` / `import_contacts_from_csv` support setting custom fields per row). If the field name doesn't match exactly, the campaign step will send the literal text `{{connectionMessage}}` to a real person instead of their personalized message, so verify this on the first handful of test leads before trusting a full batch.

The third step, the "have you seen this" bump at +3 days, uses lemlist's native `{{firstName}}` field directly in the campaign step itself and needs no custom field or Code involvement.

## Hand-off to lemlist (no custom code needed here)
- Do NOT build custom lemlist integration code. Use lemlist's existing tools directly:
  - `import_contacts_from_csv` / `import_leads_to_campaign` for pushing rows into the target campaign.

### Auto-enrollment tiering (this is what makes the pipeline hands off)
- **Tier 1 — auto-enroll, no review.** `campaignEligibility = INCLUDE` AND `businessLaunchStatus = QUALIFIED` (HIGH or MEDIUM confidence, i.e. either an exact month or a confirmed "recently") AND `websiteAnalysisConfidence = HIGH`. These import straight into the live lemlist campaign and the existing sequence sends the connection invite and first message automatically, same as it already does today. Widening this from HIGH only to HIGH or MEDIUM on launch confidence is safe because the "recently" fallback never states an unverifiable specific claim, this should meaningfully grow the auto send volume.
- **Tier 2 — weekly batch approval.** `businessLaunchStatus = DO_NOT_USE` (no real evidence the business is new at all), `MANUAL_REVIEW` eligibility rows, or LOW website confidence. Accumulate these into a single weekly digest (one list, not per contact prompts) for a single go/no go from Raka, then import the approved batch.
- **EXCLUDE** rows are never imported, automatically or otherwise.
- Rationale for the split: a wrong launch date or a misread website can't be unsent once the connect message goes out, so the confidence signals already being computed in Stage 1/2 double as the automation gate — no extra logic needed, just a threshold on data already produced.

### Standing spot check (doesn't block anything, just quality control)
- Weekly, surface 5 to 10 messages that were actually sent from Tier 1 (not drafts, actual sent output) for a quick skim. This catches drift in roast quality or tone over time before it compounds across hundreds of contacts. No approval required to proceed — informational only.

## Guardrails
- Stage 2 requires an actual screenshot, not just a text/HTML read. A page can pass the functional read (real content, working nav) and still be a visually dated PowerPoint style site per Stage 2a, and that visual read is only possible by looking at a render, never by inspecting markup alone.
- Never use hyphens, en dashes, or em dashes (-, –, —) anywhere in generated messages. This applies globally, not just inside the two templates.
- Research each contact to the standard in `docs/astra-prospect-research-master.md` before diagnosing (source tiers, evidence lenses, evidence classification, contradiction search). Research first, diagnose second.
- Angle selection for `connectionMessage`/`firstMessage` follows `docs/astra-commercial-angle-master.md`: diagnose the bottleneck, weigh candidate angles, and return `NO_STRONG_ANGLE` rather than force a cosmetic pitch.
- Every generated message follows `docs/writing-standard-anti-ai.md` (write like a competent person, not an AI): no validation tics, no honesty/pushback theatre, no "not X but Y", no forced triads, no corporate fog, no throat-clearing openers. The `connectionMessage` and `firstMessage` are the most exposed text this repo produces, so they get the reread pass at the bottom of that file before import.
- Never fabricate a launch date, a website observation, or a company purpose — every claim in a generated message must trace back to something actually found in Stage 1 or 2.
- Re-verify before reuse: a batch run more than a couple of weeks old should not be trusted for outreach without re-checking launch status and site state, since both can change.
- No stats, no company reported claims stated as fact — keep the plain language purpose and the roast grounded in what was actually observed.
- This pipeline handles enrichment and message drafting only. It does not send anything — sending stays a separate, human approved step (same as the daily Cowork loop).
